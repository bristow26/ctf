<?php 
// remember to add permissions for apache2 (www-data) to images directory so we can upload here..
// place flag.txt into /tmp folder
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>miniGallery</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<link href="css/master.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/screen.css" rel="stylesheet" type="text/css" media="screen" />
<!--[if IE 7]><link href="css/ie7-only.css" rel="stylesheet" type="text/css" media=screen><![endif]-->
<!--[if lt IE 7]><link href="css/ie6-only.css" rel="stylesheet" type="text/css" media=screen><![endif]-->
<script type="text/javascript" src="js/yetii-min.js"></script>
</head>
<body>
<div class="container header">
  <h1>View Your Images !!</h1>
  <h2>SecMN CTF</h2>
  <h3>It is probably too hard to get shell here so move on...</h3>
</div>
<div class="container content">
  <div id="tab-container-1">
    <div class="span-13">
<?php
$dir = "./images";
$image = glob("./images/*.jpg");
foreach($image as $a) {
	echo '<div class="tab" id="tab1"> <img src="'.$a.'" alt="" /></a> </div>';
}
?>
    </div> 
    
    <div class="span-5">
    	<ul id="tab-container-1-nav">
    		<li> </li>
    	</ul>
    </div>

    <div class="span-5 last">
    <h2>Upload an Image</h2>
<form action="pwnme.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload"></input></br></br>
    <input type="submit" value="Upload Image" name="submit">
</form>

<?php
$target_dir = "images/";
$uploadOk = 1;
// Check if image was submitted.
if(isset($_POST["submit"])) {
	// Check if file already exists
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
	$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
	if (file_exists($target_file)) {
		echo "<h2>File already exists.</h2></br>";
		$uploadOk = 0;
	}
	// Allow certain file formats
	if($imageFileType == "php") {
				echo "<h2>Yeah... nice try but nope! ;) </h2><br>";
				$uploadOk = 0;
			} elseif ($imageFileType == "html") {
				echo "<h2>What are you trying to pull here?</h2><br>";
				$uploadOk = 0;
			} elseif ($imageFileType == "exe") {
				echo "<h2>Don't break my image gallery with this nonsense...</h2><br>";
				$uploadOk = 0;
			} else if ($imageFileType == "sh") {
				echo "<h2>Ummm..... no</h2><br>";
				$uploadOk = 0;
			//} else if ($imageFileType == "png") {
				//echo "<h2>Only JPG images supported.</h2><br>";
				//$uploadOk = 0;
			//} else if ($imageFileType == "jpeg") {
				//echo "<h2>Only JPG images supported.</h2><br>";
				//$uploadOk = 0;
			}
			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "<h2>Sorry, your file was not uploaded.</h2></br>";
				// if everything is ok, try to upload file
			} else {
				if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
					echo "<h2>The file has been uploaded.</h2>";
					echo '<META HTTP-EQUIV="refresh" CONTENT="7">';
				} else {
					echo "<h2>Sorry, there was an error uploading your file.</h2>";
				}
			}
}
?>
    
    </div>
  </div>
</div>
<div class="container footer">
<p>SecMN CTF Challenge for Educational Purposes Only</p>
  <p>miniGallery template designed by: Jigowatt Premium Templates</a></p>
</div>
</body>
</html>